package com.example.authentication

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
