import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:roncadin_app/profile_screen.dart';
import 'package:roncadin_app/register_screen.dart';
import 'GoogleAuthentication.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}

Widget _buildTitle() { //widget con titolo della schermata
    return Center(
      child: SizedBox(
        child: Column(
          children: const <Widget>[
            Text(
              "Login",
              style: TextStyle(
                color: Colors.red,
                fontWeight: FontWeight.bold,
                fontSize: 25,
              ),
            ),
          ],
        ),
      ),
    );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  Future<FirebaseApp> _initializeFirebase() async {
    FirebaseApp firebaseapp = await Firebase.initializeApp();
  return firebaseapp;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FutureBuilder(
        future: _initializeFirebase(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.done) {
            return const LoginScreen();
          }
          return const Center(
            child:  CircularProgressIndicator(),
          );
        }
      ),

    );
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {

  //funzione per il login denominata loginUsingEmailPassword
  Future<User?> loginUsingEmailPassword({required String email, required String password, required BuildContext context}) async
    //due variabili stringhe: una per la email e una per la password
    {
      User? user; //istanza di User
      final FirebaseAuth _firebaseAuth = FirebaseAuth.instance; //istanza di Firebase Auth
      final db = FirebaseDatabase(databaseURL: "https://roncadin-application-default-rtdb.europe-west1.firebasedatabase.app/")
        .reference().child("Users"); //istanza di Firebase Realtime Database

    try 
    {
      //per accedere, è chiamato il metodo signInWithEmailAndPassword(), con il quale vengono richieste email e password
      UserCredential userCredential = await _firebaseAuth.signInWithEmailAndPassword(email: email, password: password);
      user = userCredential.user;

    } on FirebaseAuthException catch (e) { //in caso di errori, viene mostrato al centro della schermata un messaggio di errore

      showDialog(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text("Login Failed"),
          content: Text('${e.message}'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(ctx).pop();
              },
              child: const Text('Okay'),
            )
          ],
        ),
      );
    }
    return user;
  }

  @override
  Widget build(BuildContext context) {

    //vengono dichiarati due TextEditingController per email e password che vengono inserite nelle due TextField (righe 151 e 165)
    TextEditingController _emailController = TextEditingController();
    TextEditingController _passwordController = TextEditingController();
    User? user;

    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[_buildTitle()],
              ),
          const SizedBox(
            height: 30.0,
          ),
          SizedBox(
            child: Image.asset('assets/logo.png'),
          ),
          const SizedBox(
            height: 30.0,
          ),
          TextField(
            controller: _emailController,
            keyboardType: TextInputType.emailAddress,
            decoration: const InputDecoration(
              hintText: "Email",
              prefixIcon: Icon(
                Icons.mail,
                color: Colors.black,
              )
            ),
          ),
          const SizedBox(
            height: 44.0,
          ),
          TextField(
            controller: _passwordController,
            obscureText: true,
            decoration: const InputDecoration(
              hintText: "Password",
              prefixIcon: Icon(
                Icons.lock,
                color: Colors.black,
              )
            ),
          ),
          const SizedBox(
            height: 50.0,
          ),
          SizedBox(
            width: double.infinity,
            child: RawMaterialButton( //LOGIN BUTTON
              fillColor: Colors.redAccent,
              elevation: 0.0,
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              onPressed: () async {
                user = await loginUsingEmailPassword(email: _emailController.text, password: _passwordController.text, context: context);
                String? us_mail = user?.email.toString(); //per passare la email del'utente alla schermata ProfileScreen (vedi riga 191)
                if (user != null) {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => ProfileScreen(user: us_mail))); //passa alla schermata ProfileScreen
                }
              },
              child: const Text(
                "Login",
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          SizedBox(
            width: double.infinity,
            child: RawMaterialButton( //REGISTER BUTTON
              fillColor: Colors.black,
              elevation: 0.0,
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              onPressed: () async {
                Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => RegisterScreen())); //passa alla schermata RegisterScreen
              },
              child: const Text(
                "Register",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          SizedBox(
            width: double.infinity,
            child: RawMaterialButton( //SIGN IN WITH GOOGLE BUTTON
              fillColor: Colors.black,
              elevation: 0.0,
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              onPressed: () async {
                User? user = await GoogleAuthentication.signInWithGoogle(context: context); //viene richiamata la funzione signInWithGoogle appartente alla classe GoogleAuthentication
                String? us_mail = user?.email.toString(); //per passare la email del'utente alla schermata ProfileScreen (vedi riga 240)
                if (user != null) {
                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => ProfileScreen(user: us_mail))); //passa alla schermata ProfileScreen
                }
              },
              child: const Text(
                "Sign in with Google",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}