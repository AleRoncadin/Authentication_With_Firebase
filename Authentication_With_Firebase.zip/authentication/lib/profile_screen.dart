import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/material.dart';
import 'package:roncadin_app/GoogleAuthentication.dart';
import 'package:roncadin_app/main.dart';

final db = FirebaseDatabase(databaseURL: "https://roncadin-application-default-rtdb.europe-west1.firebasedatabase.app/").reference().child("Users");

Widget _buildTitle() {
    return Center(
      child: Column(
        children: const <Widget>[
          Text(
            "HOME",
            style: TextStyle(
              color: Colors.red,
              fontWeight: FontWeight.bold,
              fontSize: 25,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
}

class ProfileScreen extends StatefulWidget {
  final user;
  const ProfileScreen({ Key? key, this.user}): super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {

  @override
  Widget build(BuildContext context) {
    var user = widget.user.toString();

    String welcomeMsg = "Welcome, you are now logged as $user";
    
    return Scaffold(
      appBar: AppBar(title: _buildTitle(), backgroundColor: Colors.black,),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            /*const SizedBox(
              height: 5.0,
            ),*/
            Container(
              width: double.infinity,
              child: Text(welcomeMsg,
              textAlign: TextAlign.center,
                style: const TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 11,
              ),
              ),
              color: Colors.red,
            ),       
          const SizedBox(
              height: 400.0,
            ),
          SizedBox(
            width: double.infinity,
            child: RawMaterialButton(
              fillColor: Colors.black,
              elevation: 0.0,
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              onPressed: () async {
                try{
                  await GoogleAuthentication.signOut(context: context);
                  await FirebaseAuth.instance.signOut();
                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => HomePage()));
                } catch (e) { 
                  print("Cannot logout");
                }
              },
              child: const Text(
                "Logout",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          ],
          ),
        ),
    );
  }
}