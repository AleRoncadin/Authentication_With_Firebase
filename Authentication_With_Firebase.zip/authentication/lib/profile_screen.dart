import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:roncadin_app/GoogleAuthentication.dart';
import 'package:roncadin_app/main.dart';

//titolo della schermata
Widget _buildTitle() {
    return Center(
      child: Column(
        children: const <Widget>[
          Text(
            "HOME",
            style: TextStyle(
              color: Colors.red,
              fontWeight: FontWeight.bold,
              fontSize: 25,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
}

class ProfileScreen extends StatefulWidget {
  final user;
  const ProfileScreen({ Key? key, this.user}): super(key: key);

  @override
  _ProfileScreenState createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {

  @override
  Widget build(BuildContext context) {
    var user = widget.user.toString();

    String welcomeMsg = "Welcome, you are now logged as $user"; //messaggio di benvenuto con email utente (utile per verificare se l'email dell'utente è corretta)
    
    return Scaffold(
      appBar: AppBar(title: _buildTitle(), backgroundColor: Colors.black,),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: double.infinity,
              child: Text(
                welcomeMsg, //messaggio di benvenuto
              textAlign: TextAlign.center,
                style: const TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 11,
              ),
              ),
              color: Colors.red,
            ),       
          const SizedBox(
              height: 400.0,
            ),
          SizedBox(
            width: double.infinity,
            child: RawMaterialButton( //LOGOUT BUTTON
              fillColor: Colors.black,
              elevation: 0.0,
              padding: const EdgeInsets.symmetric(vertical: 10.0),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              onPressed: () async {
                try{
                  await GoogleAuthentication.signOut(context: context); //se l'utente si è autenticato con Google avviene il signOut di Google
                  await FirebaseAuth.instance.signOut(); //disconnette l'utente
                  Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (context) => const HomePage())); //torna alla schermata iniziale
                } on FirebaseAuthException catch (e) { 
                  showDialog( //in caso di errori, viene mostrato al centro della schermata un messaggio di errore
                    context: context,
                    builder: (ctx) => AlertDialog(
                      title: const Text("Logout Failed"),
                      content: Text('${e.message}'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.of(ctx).pop();
                          },
                          child: const Text('Okay'),
                        )
                      ],
                    ),
                  );
                }
              },
              child: const Text(
                "Logout",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 20.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          ],
          ),
        ),
    );
  }
}