import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:firebase_database/firebase_database.dart';

class GoogleAuthentication { 

  static Future<User?> signInWithGoogle({required BuildContext context}) async {

    FirebaseAuth auth = FirebaseAuth.instance; //create a new Firebase Auth instance

    final db = FirebaseDatabase(databaseURL: "https://roncadin-application-default-rtdb.europe-west1.firebasedatabase.app/")
    .reference().child("Users"); //create Firebase Realtime Database instance

    User? user; //create User instance
    final GoogleSignInAccount? googleSignInAccount = await GoogleSignIn().signIn();

    if (googleSignInAccount != null) {
      final GoogleSignInAuthentication googleSignInAuthentication =
          await googleSignInAccount.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleSignInAuthentication.accessToken,
        idToken: googleSignInAuthentication.idToken,
      );

      try {
          final UserCredential userCredential = await auth.signInWithCredential(credential);
          user = userCredential.user;

          //add user in firebase realtime database
          final ID = googleSignInAccount.id;
          print("ID: $ID");
          db.child(ID).set(
          {
            'email': googleSignInAccount.email,
            'nickname' : googleSignInAccount.displayName,
          }
          );

        } on FirebaseAuthException catch (e) {
          showDialog(
            context: context,
            builder: (ctx) => AlertDialog(
              title: const Text("Login Failed"),
              content: Text('${e.message}'),
              actions: [
                TextButton(
                  onPressed: () {
                    Navigator.of(ctx).pop();
                  },
                  child: const Text('Okay'),
                )
              ],
            ),
          );
        }

      return user;
    }
  }

  static Future<void> signOut({required BuildContext context}) async { //method used for the logout button
    try {
      if (!kIsWeb) { 
        await GoogleSignIn().signOut();
        }
    } catch (e) { 
      print("Cannot logout (Google)");
      }
  }
}